interface CompetitorResult {
  name: string;
  instagramHandle?: string;
  website?: string;
  verified: boolean;
}

export class RealCompetitorService {
  async searchCompetitors(searchData: {
    companyName: string;
    industryNiche: string;
    businessDescription: string;
    targetMarket?: string;
  }): Promise<CompetitorResult[]> {
    console.log(`🔍 Searching for competitors in: ${searchData.industryNiche}`);
    
    const allCompetitors: CompetitorResult[] = [];
    
    try {
      // Use Wikipedia API for company lists - completely free and reliable
      const wikiResults = await this.searchWikipedia(searchData.industryNiche);
      allCompetitors.push(...wikiResults);
      
      // Use GitHub API for tech companies - free and reliable
      const githubResults = await this.searchGitHub(searchData.industryNiche);
      allCompetitors.push(...githubResults);
      
      // Use HackerNews API for startups - free and reliable
      const hnResults = await this.searchHackerNews(searchData.industryNiche);
      allCompetitors.push(...hnResults);
      
      // Use Crunchbase via web scraping - free but limited
      const crunchbaseResults = await this.searchCrunchbase(searchData.industryNiche);
      allCompetitors.push(...crunchbaseResults);
      
      // Remove duplicates and validate
      const uniqueCompetitors = this.removeDuplicates(allCompetitors);
      
      if (uniqueCompetitors.length > 0) {
        console.log(`✅ Found ${uniqueCompetitors.length} competitors`);
        return uniqueCompetitors.slice(0, 10);
      }
      
      throw new Error(`No competitors found for "${searchData.industryNiche}". Try using more specific industry terms.`);
      
    } catch (error) {
      console.error('Competitor search failed:', error);
      throw error;
    }
  }

  private async searchWikipedia(industry: string): Promise<CompetitorResult[]> {
    const competitors: CompetitorResult[] = [];
    
    try {
      // More specific search queries for better results
      const searchQueries = [
        `List of ${industry} manufacturers`,
        `${industry} brands`,
        `${industry} companies`,
        `${industry} industry`
      ];
      
      for (const query of searchQueries) {
        const searchUrl = `https://en.wikipedia.org/api/rest_v1/page/search?q=${encodeURIComponent(query)}&limit=3`;
        const searchResponse = await fetch(searchUrl);
        
        if (searchResponse.ok) {
          const searchData = await searchResponse.json();
          
          for (const page of searchData.pages || []) {
            // Only process pages that are likely to contain company lists
            if (this.isRelevantPage(page.title, industry)) {
              const contentUrl = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(page.title)}`;
              const contentResponse = await fetch(contentUrl);
              
              if (contentResponse.ok) {
                const contentData = await contentResponse.json();
                
                if (contentData.extract) {
                  const companies = this.extractCompaniesFromText(contentData.extract, industry);
                  for (const company of companies.slice(0, 2)) {
                    if (this.isValidCompanyName(company)) {
                      competitors.push({
                        name: company,
                        website: this.generateWebsiteUrl(company),
                        verified: false
                      });
                    }
                  }
                }
              }
            }
            
            await this.delay(150);
          }
        }
        
        await this.delay(300);
      }
    } catch (error) {
      console.log('Wikipedia search error:', error);
    }
    
    return competitors;
  }

  private isRelevantPage(title: string, industry: string): boolean {
    const titleLower = title.toLowerCase();
    const industryLower = industry.toLowerCase();
    
    return titleLower.includes(industryLower) || 
           titleLower.includes('list of') || 
           titleLower.includes('companies') || 
           titleLower.includes('brands') ||
           titleLower.includes('manufacturers');
  }

  private isValidCompanyName(name: string): boolean {
    const lower = name.toLowerCase();
    const invalidTerms = [
      'wikipedia', 'category', 'united states', 'new york', 'california',
      'england', 'france', 'germany', 'china', 'india', 'company',
      'corporation', 'the company', 'this company', 'many companies'
    ];
    
    return name.length > 2 && 
           name.length < 40 && 
           !invalidTerms.some(term => lower.includes(term)) &&
           /^[A-Z]/.test(name);
  }

  private async searchGitHub(industry: string): Promise<CompetitorResult[]> {
    const competitors: CompetitorResult[] = [];
    
    try {
      const query = `${industry} in:description`;
      const response = await fetch(`https://api.github.com/search/repositories?q=${encodeURIComponent(query)}&sort=stars&order=desc&per_page=8`);
      
      if (response.ok) {
        const data = await response.json();
        
        for (const repo of data.items || []) {
          if (repo.homepage && this.isValidWebsite(repo.homepage)) {
            const companyName = this.extractCompanyName(repo.owner.login);
            if (companyName) {
              competitors.push({
                name: companyName,
                website: repo.homepage,
                verified: false
              });
            }
          }
        }
      }
    } catch (error) {
      console.log('GitHub search error:', error);
    }
    
    return competitors;
  }

  private async searchHackerNews(industry: string): Promise<CompetitorResult[]> {
    const competitors: CompetitorResult[] = [];
    
    try {
      const query = `${industry} startup company`;
      const response = await fetch(`http://hn.algolia.com/api/v1/search?query=${encodeURIComponent(query)}&tags=story&hitsPerPage=8`);
      
      if (response.ok) {
        const data = await response.json();
        
        for (const hit of data.hits || []) {
          if (hit.url && this.isValidWebsite(hit.url)) {
            const companyName = this.extractDomainName(hit.url);
            if (companyName) {
              competitors.push({
                name: companyName,
                website: hit.url,
                verified: false
              });
            }
          }
        }
      }
    } catch (error) {
      console.log('HackerNews search error:', error);
    }
    
    return competitors;
  }

  private async searchCrunchbase(industry: string): Promise<CompetitorResult[]> {
    const competitors: CompetitorResult[] = [];
    
    try {
      // Crunchbase requires API key, skipping for free implementation
      console.log('Crunchbase search skipped (requires API key):', industry);
      
    } catch (error) {
      console.log('Crunchbase search error:', error);
    }
    
    return competitors;
  }

  private extractCompaniesFromText(text: string, industry: string): string[] {
    const companies: string[] = [];
    
    // Enhanced regex patterns for company extraction
    const patterns = [
      /\b([A-Z][a-z]+(?:\s+&\s+[A-Z][a-z]+)*)\b/g,
      /\b([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\b/g,
      /\b([A-Z][a-z]+\s+(?:Inc|Ltd|Corp|LLC|Co|Company|Corporation)\.?)\b/g
    ];
    
    for (const pattern of patterns) {
      const matches = text.match(pattern);
      if (matches) {
        companies.push(...matches);
      }
    }
    
    // Filter out common non-company terms
    return companies.filter(company => {
      const lower = company.toLowerCase();
      return !lower.includes('united states') && 
             !lower.includes('new york') && 
             !lower.includes('wikipedia') &&
             !lower.includes('category') &&
             company.length > 2;
    });
  }

  private extractCompanyName(input: string): string | null {
    if (!input) return null;
    
    // Convert username/handle to company name
    const cleaned = input.replace(/[-_]/g, ' ')
                        .replace(/\b\w/g, l => l.toUpperCase())
                        .trim();
    
    return cleaned.length > 2 ? cleaned : null;
  }

  private extractDomainName(url: string): string | null {
    try {
      const domain = new URL(url).hostname.replace('www.', '');
      const parts = domain.split('.');
      if (parts.length >= 2) {
        return parts[0].charAt(0).toUpperCase() + parts[0].slice(1);
      }
    } catch {
      return null;
    }
    return null;
  }

  private generateWebsiteUrl(companyName: string): string {
    const cleaned = companyName.toLowerCase()
                              .replace(/\s+/g, '')
                              .replace(/[^a-z0-9]/g, '');
    return `https://www.${cleaned}.com`;
  }

  private isValidWebsite(url: string): boolean {
    if (!url) return false;
    
    try {
      const domain = new URL(url).hostname.toLowerCase();
      const excludedDomains = [
        'wikipedia.org', 'facebook.com', 'linkedin.com', 'twitter.com',
        'instagram.com', 'youtube.com', 'reddit.com', 'github.com',
        'medium.com', 'blogspot.com', 'wordpress.com', 'tumblr.com'
      ];
      
      return !excludedDomains.some(excluded => domain.includes(excluded)) &&
             domain.includes('.') &&
             !domain.includes('blog');
    } catch {
      return false;
    }
  }

  private removeDuplicates(competitors: CompetitorResult[]): CompetitorResult[] {
    const seen = new Set<string>();
    return competitors.filter(competitor => {
      const key = competitor.name.toLowerCase().replace(/\s+/g, '');
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  private async delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}