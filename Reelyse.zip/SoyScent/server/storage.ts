import { users, competitorSearches, competitors, type User, type InsertUser, type CompetitorSearch, type InsertCompetitorSearch, type Competitor, type InsertCompetitor } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createCompetitorSearch(search: InsertCompetitorSearch): Promise<CompetitorSearch>;
  getCompetitorSearch(id: number): Promise<CompetitorSearch | undefined>;
  createCompetitor(competitor: InsertCompetitor): Promise<Competitor>;
  getCompetitorsBySearchId(searchId: number): Promise<Competitor[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private competitorSearches: Map<number, CompetitorSearch>;
  private competitors: Map<number, Competitor>;
  private currentUserId: number;
  private currentSearchId: number;
  private currentCompetitorId: number;

  constructor() {
    this.users = new Map();
    this.competitorSearches = new Map();
    this.competitors = new Map();
    this.currentUserId = 1;
    this.currentSearchId = 1;
    this.currentCompetitorId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createCompetitorSearch(insertSearch: InsertCompetitorSearch): Promise<CompetitorSearch> {
    const id = this.currentSearchId++;
    const search: CompetitorSearch = { 
      ...insertSearch, 
      id,
      targetMarket: insertSearch.targetMarket || null,
      createdAt: new Date()
    };
    this.competitorSearches.set(id, search);
    return search;
  }

  async getCompetitorSearch(id: number): Promise<CompetitorSearch | undefined> {
    return this.competitorSearches.get(id);
  }

  async createCompetitor(insertCompetitor: InsertCompetitor): Promise<Competitor> {
    const id = this.currentCompetitorId++;
    const competitor: Competitor = { 
      id,
      name: insertCompetitor.name,
      searchId: insertCompetitor.searchId ?? null,
      instagramHandle: insertCompetitor.instagramHandle ?? null,
      website: insertCompetitor.website ?? null,
      verified: insertCompetitor.verified ?? null
    };
    this.competitors.set(id, competitor);
    return competitor;
  }

  async getCompetitorsBySearchId(searchId: number): Promise<Competitor[]> {
    return Array.from(this.competitors.values()).filter(
      (competitor) => competitor.searchId === searchId
    );
  }
}

export const storage = new MemStorage();
