interface CompetitorResult {
  name: string;
  instagramHandle?: string;
  website?: string;
  verified: boolean;
}

export class AuthenticCompetitorService {
  async searchCompetitors(searchData: {
    companyName: string;
    industryNiche: string;
    businessDescription: string;
    targetMarket?: string;
  }): Promise<CompetitorResult[]> {
    console.log(`🔍 Searching authentic competitors for: ${searchData.industryNiche}`);
    
    const allCompetitors: CompetitorResult[] = [];
    
    try {
      // First try Wikipedia API for authentic company data
      const wikiResults = await this.searchWikipediaCompanies(searchData.industryNiche);
      allCompetitors.push(...wikiResults);
      
      // If Wikipedia doesn't return enough results, use curated authentic data
      if (allCompetitors.length < 5) {
        const curatedResults = this.getAuthenticIndustryCompetitors(searchData.industryNiche);
        allCompetitors.push(...curatedResults);
      }
      
      // Remove duplicates
      const uniqueCompetitors = this.removeDuplicates(allCompetitors);
      
      if (uniqueCompetitors.length > 0) {
        console.log(`✅ Found ${uniqueCompetitors.length} authentic competitors`);
        return uniqueCompetitors.slice(0, 10);
      }
      
      throw new Error(`No authentic competitors found for "${searchData.industryNiche}". Try using more specific industry terms like "soy candles", "tech software", or "fashion clothing".`);
      
    } catch (error) {
      console.error('Authentic competitor search failed:', error);
      throw error;
    }
  }

  private async searchWikipediaCompanies(industry: string): Promise<CompetitorResult[]> {
    const competitors: CompetitorResult[] = [];
    
    try {
      // Search for industry-specific Wikipedia pages
      const searchQueries = [
        `List of ${industry} companies`,
        `${industry} manufacturers`,
        `${industry} brands`,
        `${industry} industry companies`
      ];
      
      for (const query of searchQueries.slice(0, 2)) { // Limit to prevent rate limiting
        const searchUrl = `https://en.wikipedia.org/api/rest_v1/page/search?q=${encodeURIComponent(query)}&limit=3`;
        const searchResponse = await fetch(searchUrl);
        
        if (searchResponse.ok) {
          const searchData = await searchResponse.json();
          
          for (const page of searchData.pages || []) {
            if (this.isRelevantCompanyPage(page.title, industry)) {
              const contentUrl = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(page.title)}`;
              const contentResponse = await fetch(contentUrl);
              
              if (contentResponse.ok) {
                const contentData = await contentResponse.json();
                
                if (contentData.extract) {
                  const companies = this.extractValidCompanies(contentData.extract);
                  for (const company of companies.slice(0, 3)) {
                    competitors.push({
                      name: company,
                      website: this.generateWebsiteUrl(company),
                      verified: false
                    });
                  }
                }
              }
            }
            
            await this.delay(200);
          }
        }
        
        await this.delay(500);
      }
    } catch (error) {
      console.log('Wikipedia search completed with some errors:', error);
    }
    
    return competitors;
  }

  private getAuthenticIndustryCompetitors(industry: string): CompetitorResult[] {
    const industryLower = industry.toLowerCase();
    
    // Authentic competitor data from real companies
    if (industryLower.includes('candle') || industryLower.includes('soy wax') || industryLower.includes('fragrance')) {
      return [
        { name: 'Bath & Body Works', website: 'https://www.bathandbodyworks.com', instagramHandle: 'bathandbodyworks', verified: true },
        { name: 'Yankee Candle', website: 'https://www.yankeecandle.com', instagramHandle: 'yankeecandle', verified: true },
        { name: 'Diptyque', website: 'https://www.diptyqueparis.com', instagramHandle: 'diptyque', verified: true },
        { name: 'Voluspa', website: 'https://voluspa.com', instagramHandle: 'voluspa', verified: true },
        { name: 'Capri Blue', website: 'https://capri-blue.com', instagramHandle: 'capriblue', verified: true },
        { name: 'Boy Smells', website: 'https://www.boysmells.com', instagramHandle: 'boysmells', verified: true },
        { name: 'Paddywax', website: 'https://paddywax.com', instagramHandle: 'paddywax', verified: true },
        { name: 'Nest Fragrances', website: 'https://www.nestfragrances.com', instagramHandle: 'nestfragrances', verified: true }
      ];
    }
    
    if (industryLower.includes('tech') || industryLower.includes('software') || industryLower.includes('saas')) {
      return [
        { name: 'Microsoft', website: 'https://www.microsoft.com', instagramHandle: '@microsoft', verified: true },
        { name: 'Google', website: 'https://www.google.com', instagramHandle: '@google', verified: true },
        { name: 'Apple', website: 'https://www.apple.com', instagramHandle: '@apple', verified: true },
        { name: 'Amazon', website: 'https://www.amazon.com', instagramHandle: '@amazon', verified: true },
        { name: 'Meta', website: 'https://www.meta.com', instagramHandle: '@meta', verified: true },
        { name: 'Salesforce', website: 'https://www.salesforce.com', instagramHandle: '@salesforce', verified: true },
        { name: 'Adobe', website: 'https://www.adobe.com', instagramHandle: '@adobe', verified: true },
        { name: 'Oracle', website: 'https://www.oracle.com', instagramHandle: '@oracle', verified: true }
      ];
    }
    
    if (industryLower.includes('fashion') || industryLower.includes('clothing') || industryLower.includes('apparel')) {
      return [
        { name: 'Zara', website: 'https://www.zara.com', instagramHandle: '@zara', verified: true },
        { name: 'H&M', website: 'https://www.hm.com', instagramHandle: '@hm', verified: true },
        { name: 'Nike', website: 'https://www.nike.com', instagramHandle: '@nike', verified: true },
        { name: 'Adidas', website: 'https://www.adidas.com', instagramHandle: '@adidas', verified: true },
        { name: 'Uniqlo', website: 'https://www.uniqlo.com', instagramHandle: '@uniqlo', verified: true },
        { name: 'Gap', website: 'https://www.gap.com', instagramHandle: '@gap', verified: true },
        { name: 'Forever 21', website: 'https://www.forever21.com', instagramHandle: '@forever21', verified: true },
        { name: 'Urban Outfitters', website: 'https://www.urbanoutfitters.com', instagramHandle: '@urbanoutfitters', verified: true }
      ];
    }
    
    if (industryLower.includes('food') || industryLower.includes('restaurant') || industryLower.includes('dining')) {
      return [
        { name: 'McDonalds', website: 'https://www.mcdonalds.com', instagramHandle: '@mcdonalds', verified: true },
        { name: 'Starbucks', website: 'https://www.starbucks.com', instagramHandle: '@starbucks', verified: true },
        { name: 'Subway', website: 'https://www.subway.com', instagramHandle: '@subway', verified: true },
        { name: 'KFC', website: 'https://www.kfc.com', instagramHandle: '@kfc', verified: true },
        { name: 'Pizza Hut', website: 'https://www.pizzahut.com', instagramHandle: '@pizzahut', verified: true },
        { name: 'Dominos', website: 'https://www.dominos.com', instagramHandle: '@dominos', verified: true },
        { name: 'Chipotle', website: 'https://www.chipotle.com', instagramHandle: '@chipotle', verified: true },
        { name: 'Taco Bell', website: 'https://www.tacobell.com', instagramHandle: '@tacobell', verified: true }
      ];
    }
    
    if (industryLower.includes('beauty') || industryLower.includes('cosmetics') || industryLower.includes('skincare')) {
      return [
        { name: 'Sephora', website: 'https://www.sephora.com', instagramHandle: '@sephora', verified: true },
        { name: 'Ulta Beauty', website: 'https://www.ulta.com', instagramHandle: '@ultabeauty', verified: true },
        { name: 'The Ordinary', website: 'https://theordinary.com', instagramHandle: '@theordinary', verified: true },
        { name: 'Glossier', website: 'https://www.glossier.com', instagramHandle: '@glossier', verified: true },
        { name: 'Fenty Beauty', website: 'https://fentybeauty.com', instagramHandle: '@fentybeauty', verified: true },
        { name: 'Rare Beauty', website: 'https://rarebeauty.com', instagramHandle: '@rarebeauty', verified: true },
        { name: 'MAC Cosmetics', website: 'https://www.maccosmetics.com', instagramHandle: '@maccosmetics', verified: true },
        { name: 'Maybelline', website: 'https://www.maybelline.com', instagramHandle: '@maybelline', verified: true }
      ];
    }
    
    if (industryLower.includes('fitness') || industryLower.includes('gym') || industryLower.includes('health')) {
      return [
        { name: 'Planet Fitness', website: 'https://www.planetfitness.com', instagramHandle: '@planetfitness', verified: true },
        { name: 'Gold\'s Gym', website: 'https://www.goldsgym.com', instagramHandle: '@goldsgym', verified: true },
        { name: 'Peloton', website: 'https://www.onepeloton.com', instagramHandle: '@onepeloton', verified: true },
        { name: 'Equinox', website: 'https://www.equinox.com', instagramHandle: '@equinox', verified: true },
        { name: 'CrossFit', website: 'https://www.crossfit.com', instagramHandle: '@crossfit', verified: true },
        { name: 'SoulCycle', website: 'https://www.soul-cycle.com', instagramHandle: '@soulcycle', verified: true },
        { name: 'Life Time', website: 'https://www.lifetime.life', instagramHandle: '@lifetimefitness', verified: true },
        { name: 'LA Fitness', website: 'https://www.lafitness.com', instagramHandle: '@lafitness', verified: true }
      ];
    }
    
    if (industryLower.includes('coffee') || industryLower.includes('cafe') || industryLower.includes('beverage')) {
      return [
        { name: 'Starbucks', website: 'https://www.starbucks.com', instagramHandle: '@starbucks', verified: true },
        { name: 'Dunkin', website: 'https://www.dunkindonuts.com', instagramHandle: '@dunkin', verified: true },
        { name: 'Costa Coffee', website: 'https://www.costa.co.uk', instagramHandle: '@costacoffee', verified: true },
        { name: 'Tim Hortons', website: 'https://www.timhortons.com', instagramHandle: '@timhortons', verified: true },
        { name: 'Peet\'s Coffee', website: 'https://www.peets.com', instagramHandle: '@peetscoffee', verified: true },
        { name: 'Blue Bottle Coffee', website: 'https://bluebottlecoffee.com', instagramHandle: '@bluebottlecoffee', verified: true }
      ];
    }
    
    // Return empty array if no match - forces user to be more specific
    return [];
  }

  private isRelevantCompanyPage(title: string, industry: string): boolean {
    const titleLower = title.toLowerCase();
    const industryLower = industry.toLowerCase();
    
    return (titleLower.includes(industryLower) || titleLower.includes('list of')) &&
           (titleLower.includes('companies') || titleLower.includes('brands') || titleLower.includes('manufacturers'));
  }

  private extractValidCompanies(text: string): string[] {
    const companies: string[] = [];
    
    // Look for proper company names
    const patterns = [
      /([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)/g,
      /([A-Z][a-z]+\s+(?:Inc|Ltd|Corp|LLC|Co|Company)\.?)/g,
      /([A-Z][a-z]+\s+&\s+[A-Z][a-z]+)/g
    ];
    
    for (const pattern of patterns) {
      const matches = text.match(pattern);
      if (matches) {
        companies.push(...matches);
      }
    }
    
    // Filter valid company names
    return companies.filter(company => {
      const lower = company.toLowerCase();
      const invalidTerms = [
        'wikipedia', 'category', 'united states', 'new york', 'company',
        'corporation', 'many companies', 'the company', 'other companies'
      ];
      
      return company.length > 2 && 
             company.length < 40 && 
             !invalidTerms.some(term => lower.includes(term)) &&
             /^[A-Z]/.test(company);
    });
  }

  private generateWebsiteUrl(companyName: string): string {
    const cleaned = companyName.toLowerCase()
                              .replace(/\s+/g, '')
                              .replace(/[^a-z0-9]/g, '');
    return `https://www.${cleaned}.com`;
  }

  private removeDuplicates(competitors: CompetitorResult[]): CompetitorResult[] {
    const seen = new Set<string>();
    return competitors.filter(competitor => {
      const key = competitor.name.toLowerCase().replace(/\s+/g, '');
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  private async delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}