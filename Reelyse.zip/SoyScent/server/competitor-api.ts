// Real-time competitor discovery using the best free APIs
interface CompetitorResult {
  name: string;
  instagramHandle?: string;
  website?: string;
  verified: boolean;
}

export class CompetitorAPIService {
  async searchCompetitors(searchData: {
    companyName: string;
    industryNiche: string;
    businessDescription: string;
    targetMarket?: string;
  }): Promise<CompetitorResult[]> {
    console.log(`🔍 Real-time search for: ${searchData.industryNiche}`);
    
    const allCompetitors: CompetitorResult[] = [];
    
    try {
      // Use multiple proven free APIs in parallel
      const [serperResults, rapidApiResults, wikiResults, freeApiResults] = await Promise.all([
        this.searchWithSerperAPI(searchData.industryNiche),
        this.searchWithRapidAPI(searchData.industryNiche),
        this.searchWithWikipediaAPI(searchData.industryNiche),
        this.searchWithFreeBusinessAPIs(searchData.industryNiche)
      ]);
      
      allCompetitors.push(...serperResults);
      allCompetitors.push(...rapidApiResults);
      allCompetitors.push(...wikiResults);
      allCompetitors.push(...freeApiResults);
      
      // Remove duplicates and validate
      const uniqueCompetitors = this.removeDuplicates(allCompetitors);
      const validatedCompetitors = await this.validateCompetitorLinks(uniqueCompetitors);
      
      if (validatedCompetitors.length > 0) {
        console.log(`✅ Found ${validatedCompetitors.length} verified competitors`);
        return validatedCompetitors.slice(0, 12);
      }
      
      throw new Error(`No verified competitors found for "${searchData.industryNiche}". The industry may have limited online presence.`);
      
    } catch (error) {
      console.error('All competitor searches failed:', error);
      throw error;
    }
  }

  private async searchWithSerperAPI(industry: string): Promise<CompetitorResult[]> {
    const competitors: CompetitorResult[] = [];
    
    try {
      // Serper.dev provides free Google search API
      const apiKey = process.env.SERPER_API_KEY;
      if (!apiKey) {
        console.log('Serper API key not found, skipping...');
        return [];
      }
      
      const query = `${industry} companies business website`;
      const response = await fetch('https://google.serper.dev/search', {
        method: 'POST',
        headers: {
          'X-API-KEY': apiKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          q: query,
          num: 10
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        
        if (data.organic) {
          for (const result of data.organic.slice(0, 6)) {
            if (this.isValidBusinessWebsite(result.link)) {
              competitors.push({
                name: this.extractBusinessName(result.title),
                website: result.link,
                verified: true
              });
            }
          }
        }
      }
    } catch (error) {
      console.log('Serper API search failed:', error);
    }
    
    return competitors;
  }

  private async searchWithRapidAPI(industry: string): Promise<CompetitorResult[]> {
    const competitors: CompetitorResult[] = [];
    
    try {
      // RapidAPI has many free business directory APIs
      const apiKey = process.env.RAPIDAPI_KEY;
      if (!apiKey) {
        console.log('RapidAPI key not found, skipping...');
        return [];
      }
      
      // Use Real-Time Search API from RapidAPI
      const query = `${industry} business directory`;
      const response = await fetch('https://real-time-web-search.p.rapidapi.com/search', {
        method: 'POST',
        headers: {
          'X-RapidAPI-Key': apiKey,
          'X-RapidAPI-Host': 'real-time-web-search.p.rapidapi.com',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          q: query,
          limit: 10
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        
        if (data.data) {
          for (const result of data.data.slice(0, 5)) {
            if (this.isValidBusinessWebsite(result.url)) {
              competitors.push({
                name: this.extractBusinessName(result.title),
                website: result.url,
                verified: true
              });
            }
          }
        }
      }
    } catch (error) {
      console.log('RapidAPI search failed:', error);
    }
    
    return competitors;
  }

  private async searchWithWikipediaAPI(industry: string): Promise<CompetitorResult[]> {
    const competitors: CompetitorResult[] = [];
    
    try {
      // Wikipedia API is completely free and reliable
      const searchQueries = [
        `${industry} companies`,
        `List of ${industry} companies`,
        `${industry} industry`
      ];
      
      for (const query of searchQueries) {
        // Search for relevant pages
        const searchResponse = await fetch(
          `https://en.wikipedia.org/api/rest_v1/page/search?q=${encodeURIComponent(query)}&limit=5`
        );
        
        if (searchResponse.ok) {
          const searchData = await searchResponse.json();
          
          for (const page of searchData.pages || []) {
            // Get page content
            const contentResponse = await fetch(
              `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(page.title)}`
            );
            
            if (contentResponse.ok) {
              const contentData = await contentResponse.json();
              
              if (contentData.extract) {
                const companies = this.extractCompaniesFromWikipedia(contentData.extract);
                for (const company of companies.slice(0, 3)) {
                  const website = await this.findCompanyWebsite(company);
                  if (website) {
                    competitors.push({
                      name: company,
                      website: website,
                      verified: false
                    });
                  }
                }
              }
            }
            
            await this.delay(100); // Rate limiting
          }
        }
        
        await this.delay(200);
      }
    } catch (error) {
      console.log('Wikipedia API search failed:', error);
    }
    
    return competitors;
  }

  private async searchWithFreeBusinessAPIs(industry: string): Promise<CompetitorResult[]> {
    const competitors: CompetitorResult[] = [];
    
    try {
      // Use HackerNews API for tech companies
      if (industry.toLowerCase().includes('tech') || industry.toLowerCase().includes('software')) {
        const hnCompetitors = await this.searchHackerNewsAPI(industry);
        competitors.push(...hnCompetitors);
      }
      
      // Use GitHub API for open source projects/companies
      const githubCompetitors = await this.searchGitHubAPI(industry);
      competitors.push(...githubCompetitors);
      
      // Use ProductHunt API for startups
      const phCompetitors = await this.searchProductHuntAPI(industry);
      competitors.push(...phCompetitors);
      
    } catch (error) {
      console.log('Free business APIs search failed:', error);
    }
    
    return competitors;
  }

  private async searchHackerNewsAPI(industry: string): Promise<CompetitorResult[]> {
    const competitors: CompetitorResult[] = [];
    
    try {
      const query = `${industry} startup company`;
      const response = await fetch(`http://hn.algolia.com/api/v1/search?query=${encodeURIComponent(query)}&tags=story&hitsPerPage=10`);
      
      if (response.ok) {
        const data = await response.json();
        
        for (const hit of data.hits || []) {
          if (hit.url && this.isValidBusinessWebsite(hit.url)) {
            const companyName = this.extractDomainName(hit.url);
            if (companyName) {
              competitors.push({
                name: companyName,
                website: hit.url,
                verified: false
              });
            }
          }
        }
      }
    } catch (error) {
      console.log('HackerNews API search failed:', error);
    }
    
    return competitors;
  }

  private async searchGitHubAPI(industry: string): Promise<CompetitorResult[]> {
    const competitors: CompetitorResult[] = [];
    
    try {
      const query = `${industry} in:description`;
      const response = await fetch(`https://api.github.com/search/repositories?q=${encodeURIComponent(query)}&sort=stars&order=desc&per_page=10`);
      
      if (response.ok) {
        const data = await response.json();
        
        for (const repo of data.items || []) {
          if (repo.homepage && this.isValidBusinessWebsite(repo.homepage)) {
            const companyName = repo.owner.login.replace(/[-_]/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
            competitors.push({
              name: companyName,
              website: repo.homepage,
              verified: false
            });
          }
        }
      }
    } catch (error) {
      console.log('GitHub API search failed:', error);
    }
    
    return competitors;
  }

  private async searchProductHuntAPI(industry: string): Promise<CompetitorResult[]> {
    const competitors: CompetitorResult[] = [];
    
    try {
      // ProductHunt doesn't have a free public API, but we can use their RSS feeds
      const response = await fetch('https://www.producthunt.com/feed.xml');
      
      if (response.ok) {
        const xmlText = await response.text();
        
        // Simple XML parsing for company names and links
        const items = xmlText.match(/<item>[\s\S]*?<\/item>/g) || [];
        
        for (const item of items.slice(0, 5)) {
          const titleMatch = item.match(/<title><!\[CDATA\[(.*?)\]\]><\/title>/);
          const linkMatch = item.match(/<link>(.*?)<\/link>/);
          
          if (titleMatch && linkMatch) {
            const title = titleMatch[1];
            const link = linkMatch[1];
            
            if (title.toLowerCase().includes(industry.toLowerCase().split(' ')[0])) {
              competitors.push({
                name: title.split(' - ')[0],
                website: link,
                verified: false
              });
            }
          }
        }
      }
    } catch (error) {
      console.log('ProductHunt search failed:', error);
    }
    
    return competitors;
  }

  private async findCompanyWebsite(companyName: string): Promise<string | null> {
    try {
      // Try common website patterns
      const patterns = [
        `https://www.${companyName.toLowerCase().replace(/\s+/g, '')}.com`,
        `https://www.${companyName.toLowerCase().replace(/\s+/g, '-')}.com`,
        `https://${companyName.toLowerCase().replace(/\s+/g, '')}.com`,
        `https://www.${companyName.toLowerCase().replace(/\s+/g, '')}.co`,
        `https://www.${companyName.toLowerCase().replace(/\s+/g, '')}.io`
      ];
      
      for (const url of patterns) {
        try {
          const response = await fetch(url, { method: 'HEAD', timeout: 3000 });
          if (response.ok) {
            return url;
          }
        } catch {
          continue;
        }
      }
    } catch (error) {
      console.log(`Could not find website for: ${companyName}`);
    }
    
    return null;
  }

  private extractCompaniesFromWikipedia(text: string): string[] {
    const companies: string[] = [];
    
    // Enhanced pattern matching for company names
    const patterns = [
      /([A-Z][a-z]+ [A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/g,
      /([A-Z][a-z]+(?:\s+&\s+[A-Z][a-z]+)+)/g,
      /([A-Z][a-z]+\s+(?:Inc|Ltd|Corp|LLC|Co)\.?)/g,
      /([A-Z][a-z]+\s+[A-Z][a-z]+\s+(?:Company|Corporation|Limited))/g
    ];
    
    for (const pattern of patterns) {
      const matches = text.match(pattern);
      if (matches) {
        companies.push(...matches.slice(0, 8));
      }
    }
    
    // Filter out common non-company words
    const filtered = companies.filter(company => {
      const lower = company.toLowerCase();
      return !lower.includes('united states') && 
             !lower.includes('new york') && 
             !lower.includes('los angeles') &&
             company.length > 3 &&
             company.length < 50;
    });
    
    return [...new Set(filtered)];
  }

  private extractBusinessName(title: string): string {
    return title.split(' - ')[0].split(' | ')[0].split(':')[0].trim();
  }

  private extractDomainName(url: string): string | null {
    try {
      const domain = new URL(url).hostname.replace('www.', '');
      const parts = domain.split('.');
      if (parts.length >= 2) {
        return parts[0].charAt(0).toUpperCase() + parts[0].slice(1);
      }
    } catch {
      return null;
    }
    return null;
  }

  private isValidBusinessWebsite(url: string): boolean {
    if (!url) return false;
    
    try {
      const domain = new URL(url).hostname.toLowerCase();
      const excludedDomains = [
        'wikipedia.org', 'facebook.com', 'linkedin.com', 'twitter.com', 
        'instagram.com', 'youtube.com', 'reddit.com', 'github.com',
        'medium.com', 'blogspot.com', 'wordpress.com'
      ];
      
      return !excludedDomains.some(excluded => domain.includes(excluded)) &&
             domain.includes('.') &&
             !domain.includes('blog') &&
             !domain.includes('news');
    } catch {
      return false;
    }
  }

  private removeDuplicates(competitors: CompetitorResult[]): CompetitorResult[] {
    const seen = new Set<string>();
    return competitors.filter(competitor => {
      const key = competitor.name.toLowerCase().replace(/\s+/g, '');
      if (seen.has(key)) return false;
      seen.add(key);
      return competitor.name.length > 2;
    });
  }

  private async validateCompetitorLinks(competitors: CompetitorResult[]): Promise<CompetitorResult[]> {
    const validated: CompetitorResult[] = [];
    
    for (const competitor of competitors) {
      if (!competitor.website) {
        // Keep competitors without websites if they have other info
        if (competitor.instagramHandle) {
          validated.push(competitor);
        }
        continue;
      }
      
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);
        
        const response = await fetch(competitor.website, {
          method: 'HEAD',
          signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        if (response.ok || response.status === 405) { // 405 = Method Not Allowed but site exists
          validated.push(competitor);
        }
      } catch (error) {
        console.log(`Removed competitor with invalid website: ${competitor.name}`);
      }
    }
    
    return validated;
  }

  private async delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}