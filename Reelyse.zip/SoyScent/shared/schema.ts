import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const competitorSearches = pgTable("competitor_searches", {
  id: serial("id").primaryKey(),
  companyName: text("company_name").notNull(),
  industryNiche: text("industry_niche").notNull(),
  businessDescription: text("business_description").notNull(),
  targetMarket: text("target_market"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const competitors = pgTable("competitors", {
  id: serial("id").primaryKey(),
  searchId: integer("search_id").references(() => competitorSearches.id),
  name: text("name").notNull(),
  instagramHandle: text("instagram_handle"),
  website: text("website"),
  verified: boolean("verified").default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertCompetitorSearchSchema = createInsertSchema(competitorSearches).pick({
  companyName: true,
  industryNiche: true,
  businessDescription: true,
  targetMarket: true,
});

export const insertCompetitorSchema = createInsertSchema(competitors).pick({
  searchId: true,
  name: true,
  instagramHandle: true,
  website: true,
  verified: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertCompetitorSearch = z.infer<typeof insertCompetitorSearchSchema>;
export type CompetitorSearch = typeof competitorSearches.$inferSelect;
export type InsertCompetitor = z.infer<typeof insertCompetitorSchema>;
export type Competitor = typeof competitors.$inferSelect;
