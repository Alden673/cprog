# Competitor Analysis Tool

## Overview

This is a full-stack competitor analysis tool built with React/TypeScript frontend and Node.js/Express backend. The application allows users to input business information and discover competitors through various search methods including business directories, social media platforms, and web searches.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with hot module replacement
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom dark theme
- **State Management**: TanStack React Query for server state
- **Form Handling**: React Hook Form with Zod validation
- **Routing**: Wouter for lightweight client-side routing

### Backend Architecture  
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Style**: RESTful endpoints under `/api` prefix
- **Request Handling**: JSON body parsing and URL encoding support
- **Error Handling**: Centralized error middleware with proper HTTP status codes

### Data Storage Solutions
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: PostgreSQL (configured for Neon serverless)
- **Schema Management**: Drizzle Kit for migrations
- **Development Storage**: In-memory storage class for testing
- **Session Management**: PostgreSQL-backed sessions via connect-pg-simple

### Authentication and Authorization
- **Session-based**: Express sessions stored in PostgreSQL
- **User Management**: Username/password with hashed storage
- **Protected Routes**: Session validation middleware

## Key Components

### Database Schema
- **Users Table**: Basic user authentication (id, username, password)
- **Competitor Searches Table**: Search parameters and metadata
- **Competitors Table**: Discovered competitor information with verification status

### API Endpoints
- `POST /api/competitors/search` - Execute competitor discovery
- User authentication endpoints (registration/login)
- CRUD operations for competitor data

### Frontend Pages
- **Competitor Analysis**: Main application interface with form and results
- **404 Page**: Error handling for undefined routes

### UI Components
- **CompetitorForm**: Business information input with validation
- **CompetitorResults**: Display discovered competitors with export functionality
- **Comprehensive UI Kit**: 40+ shadcn/ui components for consistent design

## Data Flow

1. **User Input**: Business details entered via validated form
2. **API Request**: Form data sent to competitor search endpoint
3. **Multi-Source Search**: Backend queries business directories, social media, and web sources
4. **Data Processing**: Results deduplicated and validated
5. **Database Storage**: Search parameters and results persisted
6. **Frontend Display**: Results shown in interactive table with export options

## External Dependencies

### Production Dependencies
- **Database**: @neondatabase/serverless for PostgreSQL connectivity
- **UI Framework**: Extensive Radix UI component library
- **Form Validation**: Zod schema validation with React Hook Form
- **HTTP Client**: Built-in fetch with React Query caching
- **Styling**: Tailwind CSS with class-variance-authority utilities

### Development Dependencies  
- **Build Tools**: Vite with React plugin and TypeScript
- **Database Tools**: Drizzle Kit for schema management
- **Code Quality**: TypeScript strict mode enabled

## Deployment Strategy

### Build Process
- **Frontend**: Vite production build to `dist/public`
- **Backend**: ESBuild bundling of server code to `dist/index.js`
- **Assets**: Static file serving with Express

### Environment Configuration
- **Development**: `tsx` for TypeScript execution with hot reload
- **Production**: Compiled JavaScript execution
- **Database**: Environment variable-based connection string

### Hosting Platform
- **Target**: Replit autoscale deployment
- **Port Configuration**: Internal 5000, external 80
- **Process Management**: npm scripts for dev/build/start

## Recent Changes

```
- June 21, 2025: Initial dark-themed competitor analysis tool setup
- June 21, 2025: Implemented authentic competitor discovery system
- June 21, 2025: Built comprehensive industry competitor database with verified companies
- June 21, 2025: Added Wikipedia API integration for real-time company discovery
- June 21, 2025: Fixed Instagram links and React key prop warnings
- June 21, 2025: System now returns authentic competitors across all industries
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```