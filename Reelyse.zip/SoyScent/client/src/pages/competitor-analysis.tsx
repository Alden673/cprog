import { useState } from 'react';
import { Building, Search, Settings, HelpCircle } from 'lucide-react';
import CompetitorForm from '@/components/competitor-form';
import CompetitorResults from '@/components/competitor-results';
import { Button } from '@/components/ui/button';

export default function CompetitorAnalysis() {
  const [searchResults, setSearchResults] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSearchComplete = (results: any) => {
    setSearchResults(results);
    setIsLoading(false);
  };

  const handleSearchStart = () => {
    setIsLoading(true);
    setSearchResults(null);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <Search className="text-primary text-xl" />
              <h1 className="text-xl font-semibold text-foreground">Competitor Analysis Tool</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <HelpCircle className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Settings className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-5 gap-8 min-h-[calc(100vh-8rem)]">
          {/* Left Panel - Company Information Form */}
          <div className="lg:col-span-2">
            <CompetitorForm 
              onSearchStart={handleSearchStart}
              onSearchComplete={handleSearchComplete}
            />
          </div>

          {/* Right Panel - Competitor Results */}
          <div className="lg:col-span-3">
            <CompetitorResults 
              results={searchResults}
              isLoading={isLoading}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
