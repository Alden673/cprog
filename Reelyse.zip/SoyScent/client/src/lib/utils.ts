import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatUrl(url: string): string {
  if (!url) return '';
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    return `https://${url}`;
  }
  return url;
}

export function extractDomain(url: string): string {
  try {
    const domain = new URL(formatUrl(url)).hostname;
    return domain.replace('www.', '');
  } catch {
    return url;
  }
}

export function validateInstagramHandle(handle: string): boolean {
  const cleanHandle = handle.replace('@', '');
  const regex = /^[a-zA-Z0-9._]{1,30}$/;
  return regex.test(cleanHandle);
}

export function formatInstagramUrl(handle: string): string {
  const cleanHandle = handle.replace('@', '');
  return `https://instagram.com/${cleanHandle}`;
}

export function exportToCsv(data: any[], filename: string) {
  if (!data.length) return;
  
  const headers = Object.keys(data[0]);
  const csvContent = [
    headers.join(','),
    ...data.map(row => 
      headers.map(header => 
        typeof row[header] === 'string' && row[header].includes(',') 
          ? `"${row[header]}"` 
          : row[header] || ''
      ).join(',')
    )
  ].join('\n');
  
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
