import { useState } from 'react';
import { Building, Tags, FileText, Users, Search } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

const formSchema = z.object({
  companyName: z.string().min(1, 'Company name is required'),
  industryNiche: z.string().min(1, 'Industry & niche is required'),
  businessDescription: z.string().min(10, 'Business description must be at least 10 characters'),
  targetMarket: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

interface CompetitorFormProps {
  onSearchStart: () => void;
  onSearchComplete: (results: any) => void;
}

export default function CompetitorForm({ onSearchStart, onSearchComplete }: CompetitorFormProps) {
  const { toast } = useToast();
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      companyName: '',
      industryNiche: '',
      businessDescription: '',
      targetMarket: '',
    },
  });

  const searchMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await apiRequest('POST', '/api/competitors/search', data);
      return response.json();
    },
    onSuccess: (data) => {
      onSearchComplete(data);
      toast({
        title: 'Search completed',
        description: `Found ${data.competitors.length} competitors`,
      });
    },
    onError: (error: any) => {
      console.error('Search error:', error);
      toast({
        title: 'Search failed',
        description: 'Unable to search for competitors. Please try again.',
        variant: 'destructive',
      });
      onSearchComplete(null);
    },
  });

  const onSubmit = (data: FormData) => {
    onSearchStart();
    searchMutation.mutate(data);
  };

  return (
    <Card className="competitor-form h-fit">
      <CardHeader>
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Building className="text-primary" />
          Company Information
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Company Name Field */}
          <div className="form-field">
            <Label className="form-label">
              <Building className="text-muted-foreground w-4 h-4" />
              Company Name <span className="text-destructive">*</span>
            </Label>
            <Input
              {...form.register('companyName')}
              className="form-input"
              placeholder="Enter your company name"
            />
            {form.formState.errors.companyName && (
              <p className="text-destructive text-sm">{form.formState.errors.companyName.message}</p>
            )}
          </div>

          {/* Industry & Niche Field */}
          <div className="form-field">
            <Label className="form-label">
              <Tags className="text-muted-foreground w-4 h-4" />
              Industry & Niche <span className="text-destructive">*</span>
            </Label>
            <Input
              {...form.register('industryNiche')}
              className="form-input"
              placeholder="e.g., candles and smell and home interiors"
            />
            {form.formState.errors.industryNiche && (
              <p className="text-destructive text-sm">{form.formState.errors.industryNiche.message}</p>
            )}
          </div>

          {/* Business Description Field */}
          <div className="form-field">
            <Label className="form-label">
              <FileText className="text-muted-foreground w-4 h-4" />
              Business Description & USP <span className="text-destructive">*</span>
            </Label>
            <Textarea
              {...form.register('businessDescription')}
              className="form-textarea"
              rows={4}
              placeholder="Describe your business and unique selling proposition"
            />
            {form.formState.errors.businessDescription && (
              <p className="text-destructive text-sm">{form.formState.errors.businessDescription.message}</p>
            )}
          </div>

          {/* Target Market Field */}
          <div className="form-field">
            <Label className="form-label">
              <Users className="text-muted-foreground w-4 h-4" />
              Target Market <span className="text-muted-foreground">(Optional)</span>
            </Label>
            <Input
              {...form.register('targetMarket')}
              className="form-input"
              placeholder="e.g., Home decor enthusiasts, Tech professionals, Fashion lovers"
            />
          </div>

          {/* Search Button */}
          <Button 
            type="submit"
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium py-3 px-6"
            disabled={searchMutation.isPending}
          >
            <Search className="w-4 h-4 mr-2" />
            {searchMutation.isPending ? 'Searching...' : 'Find Competitors'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
