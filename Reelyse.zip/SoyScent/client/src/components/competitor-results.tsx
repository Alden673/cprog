import { TrendingUp, Download, RefreshCw, AlertTriangle, Info, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { FaInstagram } from 'react-icons/fa';

interface Competitor {
  id: number;
  name: string;
  instagramHandle?: string;
  website?: string;
  verified: boolean;
}

interface CompetitorResultsProps {
  results: {
    searchId: number;
    competitors: Competitor[];
  } | null;
  isLoading: boolean;
}

export default function CompetitorResults({ results, isLoading }: CompetitorResultsProps) {
  const handleExport = () => {
    if (!results?.competitors) return;
    
    const csvData = [
      ['Name', 'Instagram Handle', 'Website'],
      ...results.competitors.map(c => [
        c.name,
        c.instagramHandle || '',
        c.website || ''
      ])
    ];
    
    const csvContent = csvData.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'competitors.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const renderInstagramHandle = (handle?: string) => {
    if (!handle) return <span className="text-muted-foreground">-</span>;
    
    const cleanHandle = handle.replace(/^@+/, ''); // Remove any @ symbols
    const url = `https://www.instagram.com/${cleanHandle}`;
    
    return (
      <a
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center gap-1 text-pink-600 hover:text-pink-700 dark:text-pink-400 dark:hover:text-pink-300 transition-colors hover:underline"
        title={`Visit @${cleanHandle} on Instagram`}
      >
        <FaInstagram className="w-4 h-4" />
        @{cleanHandle}
      </a>
    );
  };

  const renderWebsite = (website?: string) => {
    if (!website) return <span className="text-muted-foreground">-</span>;
    
    const displayUrl = website.replace(/^https?:\/\/(www\.)?/, '');
    
    return (
      <a 
        href={website} 
        target="_blank" 
        rel="noopener noreferrer"
        className="inline-flex items-center gap-1 text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 transition-colors"
      >
        <ExternalLink className="w-3 h-3" />
        {displayUrl}
      </a>
    );
  };

  return (
    <Card className="competitor-results">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <TrendingUp className="text-green-500" />
            {results ? `Direct Competitors` : 'Direct Competitors'}
          </CardTitle>
          <div className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={handleExport}
              disabled={!results?.competitors?.length}
              title="Export Results"
            >
              <Download className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" title="Refresh">
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Loading State */}
        {isLoading && (
          <div className="text-center py-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-muted rounded-full mb-4">
              <RefreshCw className="w-6 h-6 text-primary animate-spin" />
            </div>
            <p className="text-muted-foreground">Searching for competitors...</p>
            <p className="text-sm text-muted-foreground mt-2">This may take a few moments</p>
          </div>
        )}

        {/* Results */}
        {results && !isLoading && results.competitors.length > 0 && (
          <div>
            <div className="text-sm text-muted-foreground mb-4">
              Below is a list of direct competitors in your industry, including their Instagram handles and websites. 
              These brands match your niche and business focus.
            </div>

            <div className="overflow-x-auto">
              <table className="competitor-table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Instagram Handle</th>
                    <th>Website</th>
                  </tr>
                </thead>
                <tbody>
                  {results.competitors.map((competitor, index) => (
                    <tr key={`${competitor.name}-${index}`}>
                      <td className="font-medium">{competitor.name}</td>
                      <td>{renderInstagramHandle(competitor.instagramHandle)}</td>
                      <td>{renderWebsite(competitor.website)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <Alert className="mt-6">
              <Info className="h-4 w-4" />
              <AlertDescription>
                These brands are recognized for their focus in your industry segment, 
                making them strong competitors to monitor and analyze.
              </AlertDescription>
            </Alert>
          </div>
        )}

        {/* Empty State */}
        {results && !isLoading && results.competitors.length === 0 && (
          <div className="text-center py-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-muted rounded-full mb-4">
              <AlertTriangle className="w-6 h-6 text-yellow-500" />
            </div>
            <h3 className="text-lg font-medium mb-2">No competitors found</h3>
            <p className="text-muted-foreground mb-4">
              Try adjusting your industry keywords or business description
            </p>
            <Button variant="outline">
              <RefreshCw className="w-4 h-4 mr-2" />
              Try Different Keywords
            </Button>
          </div>
        )}

        {/* Default State */}
        {!results && !isLoading && (
          <div className="text-center py-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-muted rounded-full mb-4">
              <TrendingUp className="w-6 h-6 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium mb-2">Ready to find competitors</h3>
            <p className="text-muted-foreground">
              Fill out the company information form to discover your direct competitors
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
